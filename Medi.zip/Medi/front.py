question = "What are the common symptoms of heart attack?"
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
new_vector_store = FAISS.load_local(
    "faiss_index", embeddings, allow_dangerous_deserialization=True
)
context=new_vector_store.similarity_search(question, k=3)
actual_context = context[0].page_content
our_prompt = f"Based on the following context, answer the question in one sentence: {question}\n\nContext: {actual_context}\n\nAnswer:"
from openai import OpenAI
client = OpenAI(
base_url="http://127.0.0.1:1234/v1",  # LM Studio API URL
api_key="lm-studio"  # Dummy key (LM Studio ignores this)
)
response = client.chat.completions.create(
model="mistral-7b-instruct-v0.3",  # LM Studio ignores model name
messages=[
    {"role": "user", "content": our_prompt}
   ],
    temperature=0.7
    )
print(response.choices[0].message.content.strip())